package com.example.EudiWallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EudiWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
