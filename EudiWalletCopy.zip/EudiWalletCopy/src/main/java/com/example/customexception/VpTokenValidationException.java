package com.example.customexception;

public class VpTokenValidationException extends Exception{
	
	public VpTokenValidationException(String message) {
		super(message);
	}

}
